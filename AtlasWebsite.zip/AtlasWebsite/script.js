console.log("Atlas JavaScript loaded!");
const menuButton = document.getElementById("menu_button");
const sidebar = document.getElementById("sidebar");
const newChatButton = document.getElementById("new_chat");
const chatList = document.getElementById("chat_list");

const messagesContainer = document.getElementById("messages");
const chatForm = document.getElementById("chat_form");
const chatInput = document.getElementById("chat_input");


// Sidebar Menu

menuButton.addEventListener("click", () => {
    sidebar.classList.toggle("open");
});

// New Chat

newChatButton.addEventListener("click", () => {
    const chatName = prompt("Enter a name for your chat:");

    if (!chatName || chatName.trim() === "") {
        return;
    }

    createChat(chatName);
});


// Chat State/Creation

let chats = []
let currentChat = null

function createChat(name) {
    const chat = {
        name: name.trim(),
        messages: []
    };

    chats.push(chat);

    currentChat = chats.length - 1;

    const chatItem = document.createElement("button");
    chatItem.classList.add("chat_item");

    const chatText = document.createElement("p");
    chatText.textContent = chat.name;

    document.querySelectorAll(".chat_item").forEach((item) => {
            item.classList.remove("active");
        });

    chatItem.appendChild(chatText);
    chatList.appendChild(chatItem);
    chatItem.classList.add("active");

    chatItem.addEventListener("click", () => {
        currentChat = chats.indexOf(chat);

        document.querySelectorAll(".chat_item").forEach((item) => {
            item.classList.remove("active");
        });

        chatItem.classList.add("active");

        loadChat();
    });
}

function loadChat() {
    messagesContainer.innerHTML = "";
    
    const chat = chats[currentChat]

    chat.messages.forEach((message) => {
        const messageElement = document.createElement("div")
        messageElement.classList.add(message.role);
        messageElement.classList.add("message");
        messageElement.textContent = message.content;
        messagesContainer.appendChild(messageElement);
    });

    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

// Message Creation

function addMessage(role, text) {
    const message = document.createElement("div")

    message.classList.add(role);
    message.classList.add("message");

    message.textContent = text;

    messagesContainer.appendChild(message);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    chats[currentChat].messages.push({ role: role, content: text});
}

// Send a message

chatForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const message = chatInput.value.trim();

    if (!message) {
        return;
    }

    chatInput.value = "";

    if (currentChat === null) {
        createChat(message);
    }

    addMessage("user", message);
	
	// AI Response (fetches a response from the server if it's live)
	
	try {
		const response = await fetch("https://variance-bald-times-reality.trycloudflare.com/chat", {
			method: "POST",
			headers: {
				"Content-Type": "application/json"
			},
			body: JSON.stringify({
				message: message
			})
		});
		
		const data = await response.json();
		
		addMessage("assistant", data.response);
    
}	catch (error) {
	console.error(error);
	addMessage("assistant", "ERROR: Couldn't connect to AtlasOS.");
}
});
