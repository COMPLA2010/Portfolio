console.log("Atlas JavaScript loaded!");
const menuButton = document.getElementById("menu_button");
const sidebar = document.getElementById("sidebar");
const newChatButton = document.getElementById("new_chat");
const chatList = document.getElementById("chat_list");

const messagesContainer = document.getElementById("messages");
const chatForm = document.getElementById("chat_form");
const chatInput = document.getElementById("chat_input");

// Sidebar Menu

menuButton.addEventListener("click", () => {
    sidebar.classList.toggle("open");
});

// New Chat

newChatButton.addEventListener("click", () => {
    const chatName = prompt("Enter a name for your chat:");

    if (!chatName || chatName.trim() === "") {
        return;
    }

    createChat(chatName);
});

// Chat State/Creation

let chats = []
let currentChat = null

function renderChatItem(chat) {
    const chatItem = document.createElement("div");
    chatItem.classList.add("chat_item");

    const chatText = document.createElement("p");
    chatText.textContent = chat.name;

    const chatSettings = document.createElement("button");
    chatSettings.classList.add("chat_settings");
    chatSettings.innerHTML = '<i class="fa-solid fa-ellipsis-vertical"></i>';

    const chatSettingsMenu = document.createElement("div");
    chatSettingsMenu.classList.add("chat_settings_menu");

    const renameButton = document.createElement("button");
    renameButton.textContent = "Rename";

    renameButton.addEventListener("click", (event) => {
        event.stopPropagation();

        const newName = prompt("Enter a new chat name:");

        if (!newName || newName.trim() === "") {
            return;
        }

        chat.name = newName.trim();
        chatText.textContent = chat.name;

        chatSettingsMenu.classList.remove("open");

        saveChats();
    });

    const deleteButton = document.createElement("button");
    deleteButton.textContent = "Delete";

    deleteButton.addEventListener("click", (event) => {
        event.stopPropagation();

        const chatIndex = chats.indexOf(chat);

        chats.splice(chatIndex, 1);
        chatItem.remove();

        if (currentChat === chatIndex) {
            currentChat = null;
            messagesContainer.innerHTML = "";
        }
        else if (currentChat > chatIndex) {
            currentChat--;
        }

        saveChats();
    });

    chatSettingsMenu.appendChild(renameButton);
    chatSettingsMenu.appendChild(deleteButton);

    chatItem.appendChild(chatText);
    chatItem.appendChild(chatSettings);
    chatItem.appendChild(chatSettingsMenu);

    chatList.appendChild(chatItem);

    chatSettings.addEventListener("click", (event) => {
        event.stopPropagation();

        chatSettingsMenu.classList.toggle("open");
    });

    if (chats[currentChat] === chat) {
        chatItem.classList.add("active");
    }

    chatItem.addEventListener("click", () => {
        currentChat = chats.indexOf(chat);

        document.querySelectorAll(".chat_item").forEach((item) => {
            item.classList.remove("active");
        });

        chatItem.classList.add("active");

        loadChat();
    });
}

function createChat(name) {
    const chat = {
        name: name.trim(),
        messages: []
    };

    chats.push(chat);

    currentChat = chats.length - 1;

    document.querySelectorAll(".chat_item").forEach((item) => {
        item.classList.remove("active");
    });

    renderChatItem(chat);

    saveChats();
    loadChat();
}

function loadChat() {
    messagesContainer.innerHTML = "";

    if (currentChat === null) {
        return;
    }
    
    const chat = chats[currentChat]

    chat.messages.forEach((message) => {
        const messageElement = document.createElement("div")
        messageElement.classList.add(message.role);
        messageElement.classList.add("message");
        messageElement.textContent = message.content;
        messagesContainer.appendChild(messageElement);
    });

    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

// Message Creation

function addMessage(role, text) {
    const message = document.createElement("div")

    message.classList.add(role);
    message.classList.add("message");

    message.textContent = text;

    messagesContainer.appendChild(message);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    chats[currentChat].messages.push({ role: role, content: text});

    saveChats();
}

// Send a message

chatForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const message = chatInput.value.trim();

    if (!message) {
        return;
    }

    chatInput.value = "";

    if (currentChat === null) {
        createChat(message);
    }

    addMessage("user", message);
	
	// AI Response (fetches a response from the server if it's live)
	
	try {
		const response = await fetch("https://impose-composed-eminem-chairs.trycloudflare.com/chat", {
			method: "POST",
			headers: {
				"Content-Type": "application/json"
			},
			body: JSON.stringify({
				message: message
			})
		});
		
		const data = await response.json();
		
		addMessage("assistant", data.response);
    
}	catch (error) {
	console.error(error);
	addMessage("assistant", "ERROR: Couldn't connect to AtlasOS.");
}
});

// Local Storage

function saveChats() {
    localStorage.setItem("chats", JSON.stringify(chats));
}

function loadChats() {
    const savedChats = localStorage.getItem("chats");

    if (!savedChats) {
        return;
    }

    chats = JSON.parse(savedChats);
}

function renderChats() {
    chatList.innerHTML = "";

    chats.forEach((chat) => {
        renderChatItem(chat);
    });
}

// Render

loadChats();
renderChats();