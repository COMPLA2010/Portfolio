



import torch
import torch.nn as nn
import torch.nn.functional as F

from transformers import AutoTokenizer
from huggingface_hub import hf_hub_download


# ============================================================
# DEVICE
# ============================================================

device = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)

print(f"Using device: {device}")

if device.type == "cuda":
    print(f"GPU: {torch.cuda.get_device_name(0)}")


# ============================================================
# HUGGING FACE
# ============================================================

REPO_ID = "REVISIONEDSTUDIOS/AtlasOS"
MODEL_FILE = "model.pt"

print("\nDownloading/loading AtlasOS checkpoint...")

CHECKPOINT_PATH = hf_hub_download(
    repo_id=REPO_ID,
    filename=MODEL_FILE
)

print(f"Checkpoint: {CHECKPOINT_PATH}")


# ============================================================
# DEFAULT CONFIG
# ============================================================

embed_size = 512
num_heads = 8
num_kv_heads = 2
ff_dim = 1376
num_layers = 12
max_seq_len = 512
dropout = 0.1


# ============================================================
# RoPE
# ============================================================

class RoPE(nn.Module):

    def __init__(
        self,
        head_dim,
        max_seq_len,
        base=10000
    ):
        super().__init__()

        inv_freq = 1.0 / (
            base ** (
                torch.arange(
                    0,
                    head_dim,
                    2
                ).float() / head_dim
            )
        )

        positions = torch.arange(
            max_seq_len
        ).float()

        freqs = torch.outer(
            positions,
            inv_freq
        )

        # IMPORTANT:
        # Keep these exactly [512, 32],
        # matching the checkpoint.
        self.register_buffer(
            "cos",
            freqs.cos()
        )

        self.register_buffer(
            "sin",
            freqs.sin()
        )


    def forward(self, q, k):

        seq_len = q.size(2)

        # [seq_len, head_dim / 2]
        cos = self.cos[:seq_len]
        sin = self.sin[:seq_len]

        # Turn into:
        # [1, 1, seq_len, head_dim / 2]
        #
        # This is only for broadcasting during
        # the actual rotation.
        cos = cos.unsqueeze(0).unsqueeze(0)
        sin = sin.unsqueeze(0).unsqueeze(0)

        q1 = q[..., ::2]
        q2 = q[..., 1::2]

        k1 = k[..., ::2]
        k2 = k[..., 1::2]

        q_rot = torch.stack(
            [
                q1 * cos - q2 * sin,
                q1 * sin + q2 * cos
            ],
            dim=-1
        ).flatten(-2)

        k_rot = torch.stack(
            [
                k1 * cos - k2 * sin,
                k1 * sin + k2 * cos
            ],
            dim=-1
        ).flatten(-2)

        return q_rot, k_rot

# ============================================================
# ATTENTION
# ============================================================

class Attention(nn.Module):

    def __init__(
        self,
        embed_size,
        num_heads,
        num_kv_heads,
        max_seq_len,
        dropout
    ):
        super().__init__()

        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads

        self.head_dim = (
            embed_size // num_heads
        )

        self.num_groups = (
            num_heads // num_kv_heads
        )

        # These match your original model
        self.q_proj = nn.Linear(
            embed_size,
            num_heads * self.head_dim,
            bias=False
        )

        self.k_proj = nn.Linear(
            embed_size,
            num_kv_heads * self.head_dim,
            bias=False
        )

        self.v_proj = nn.Linear(
            embed_size,
            num_kv_heads * self.head_dim,
            bias=False
        )

        self.out_proj = nn.Linear(
            embed_size,
            embed_size,
            bias=False
        )

        self.rope = RoPE(
            self.head_dim,
            max_seq_len
        )

        self.dropout = dropout


    def forward(self, x):

        batch_size, seq_len, _ = x.shape

        q = self.q_proj(x)
        k = self.k_proj(x)
        v = self.v_proj(x)

        q = q.view(
            batch_size,
            seq_len,
            self.num_heads,
            self.head_dim
        ).transpose(1, 2)

        k = k.view(
            batch_size,
            seq_len,
            self.num_kv_heads,
            self.head_dim
        ).transpose(1, 2)

        v = v.view(
            batch_size,
            seq_len,
            self.num_kv_heads,
            self.head_dim
        ).transpose(1, 2)

        # Rotary positional embeddings
        q, k = self.rope(q, k)

        # Grouped Query Attention
        k = k.repeat_interleave(
            self.num_groups,
            dim=1
        )

        v = v.repeat_interleave(
            self.num_groups,
            dim=1
        )

        output = F.scaled_dot_product_attention(
            q,
            k,
            v,
            dropout_p=(
                self.dropout
                if self.training
                else 0.0
            ),
            is_causal=True
        )

        output = (
            output
            .transpose(1, 2)
            .contiguous()
        )

        output = output.view(
            batch_size,
            seq_len,
            -1
        )

        return self.out_proj(output)


# ============================================================
# TRANSFORMER BLOCK
# ============================================================

class TransformerBlock(nn.Module):

    def __init__(
        self,
        embed_size,
        num_heads,
        num_kv_heads,
        ff_dim,
        max_seq_len,
        dropout
    ):
        super().__init__()

        self.attention = Attention(
            embed_size,
            num_heads,
            num_kv_heads,
            max_seq_len,
            dropout
        )

        self.norm1 = nn.RMSNorm(
            embed_size
        )

        self.ff_gate = nn.Linear(
            embed_size,
            ff_dim
        )

        self.ff_up = nn.Linear(
            embed_size,
            ff_dim
        )

        self.ff_down = nn.Linear(
            ff_dim,
            embed_size
        )

        self.norm2 = nn.RMSNorm(
            embed_size
        )


    def forward(self, x):

        # Attention
        x = x + self.attention(
            self.norm1(x)
        )

        # Feed-forward
        normalized = self.norm2(x)

        gate = self.ff_gate(
            normalized
        )

        up = self.ff_up(
            normalized
        )

        ff = F.silu(gate) * up

        ff = self.ff_down(ff)

        x = x + ff

        return x


# ============================================================
# TRANSFORMER
# ============================================================

class Transformer(nn.Module):

    def __init__(
        self,
        vocab_size,
        embed_size,
        num_heads,
        num_kv_heads,
        ff_dim,
        num_layers,
        max_seq_len,
        dropout
    ):
        super().__init__()

        self.token_embedding = nn.Embedding(
            vocab_size,
            embed_size
        )

        # IMPORTANT:
        # Your original model calls these "blocks"
        self.blocks = nn.ModuleList(
            [
                TransformerBlock(
                    embed_size,
                    num_heads,
                    num_kv_heads,
                    ff_dim,
                    max_seq_len,
                    dropout
                )
                for _ in range(num_layers)
            ]
        )

        self.norm = nn.RMSNorm(
            embed_size
        )

        # Weight tying
        self.output_layer = nn.Linear(
            embed_size,
            vocab_size,
            bias=False
        )

        self.output_layer.weight = (
            self.token_embedding.weight
        )


    def forward(self, input_ids):

        x = self.token_embedding(
            input_ids
        )

        for block in self.blocks:
            x = block(x)

        x = self.norm(x)

        logits = self.output_layer(x)

        return logits


# ============================================================
# TOKENIZER
# ============================================================

print("\nLoading tokenizer...")

tokenizer = AutoTokenizer.from_pretrained(
    "gpt2"
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

tokenizer.add_special_tokens(
    {
        "additional_special_tokens": [
            "<|im_start|>",
            "<|im_end|>"
        ]
    }
)

tokenizer.chat_template = (
    "{% for message in messages %}"
    "<|im_start|>{{ message['role'] }}\n"
    "{{ message['content'] }}"
    "<|im_end|>\n"
    "{% endfor %}"
)

vocab_size = len(tokenizer)

pad_id = tokenizer.pad_token_id

im_start_id = tokenizer.convert_tokens_to_ids(
    "<|im_start|>"
)

im_end_id = tokenizer.convert_tokens_to_ids(
    "<|im_end|>"
)

print(
    f"Tokenizer vocabulary: {vocab_size}"
)


# ============================================================
# LOAD CHECKPOINT
# ============================================================

print("\nLoading checkpoint into model...")

checkpoint = torch.load(
    CHECKPOINT_PATH,
    map_location="cpu"
)

config = checkpoint.get(
    "model_config",
    {}
)

if config:

    print(
        "Using checkpoint configuration:"
    )

    print(config)

    vocab_size = config[
        "vocab_size"
    ]

    embed_size = config[
        "embed_size"
    ]

    num_heads = config[
        "num_heads"
    ]

    num_kv_heads = config[
        "num_kv_heads"
    ]

    ff_dim = config[
        "ff_dim"
    ]

    num_layers = config[
        "num_layers"
    ]

    max_seq_len = config[
        "max_seq_len"
    ]


# ============================================================
# CREATE MODEL
# ============================================================

print("\nCreating Transformer...")

model = Transformer(
    vocab_size=vocab_size,
    embed_size=embed_size,
    num_heads=num_heads,
    num_kv_heads=num_kv_heads,
    ff_dim=ff_dim,
    num_layers=num_layers,
    max_seq_len=max_seq_len,
    dropout=dropout
)


# ============================================================
# LOAD WEIGHTS
# ============================================================

state_dict = checkpoint[
    "model_state_dict"
]

# Your checkpoint was saved after torch.compile().
#
# Original:
# _orig_mod.blocks.0....
#
# Deployment:
# blocks.0....
#
# Remove _orig_mod. from every key.

cleaned_state_dict = {}

for key, value in state_dict.items():

    if key.startswith(
        "_orig_mod."
    ):
        key = key[
            len("_orig_mod.") :
        ]

    cleaned_state_dict[key] = value


print(
    "\nLoading model weights..."
)

model.load_state_dict(
    cleaned_state_dict
)


# ============================================================
# CLEAN UP CHECKPOINT FROM RAM
# ============================================================

del checkpoint
del state_dict
del cleaned_state_dict


# ============================================================
# MOVE TO GPU
# ============================================================

print(
    "\nMoving model to device..."
)

model = model.to(device)

model.eval()

print(
    "Model loaded successfully!"
)

print(
    f"Model device: {next(model.parameters()).device}"
)


# ============================================================
# GENERATION
# ============================================================

@torch.no_grad()
def generate(
    conversation,
    num_words=80,
    temperature=0.6,
    repetition_penalty=1.35,
    top_k=50,
    top_p=0.9
):

    model.eval()

    # --------------------------------------------------------
    # FORMAT CHAT
    # --------------------------------------------------------

    formatted_chat = ""

    for role, content in conversation:

        formatted_chat += (
            f"<|im_start|>{role}\n"
            f"{content}"
            f"<|im_end|>\n"
        )

    # Tell the model to generate
    # the assistant's response
    formatted_chat += (
        "<|im_start|>assistant\n"
    )

    # --------------------------------------------------------
    # TOKENIZE
    # --------------------------------------------------------

    tokens = tokenizer.encode(
        formatted_chat,
        add_special_tokens=False
    )

    response_start = len(tokens)

    # --------------------------------------------------------
    # GENERATE
    # --------------------------------------------------------

    for _ in range(num_words):

        # Keep context within 512 tokens
        input_tokens = torch.tensor(
            [
                tokens[-max_seq_len:]
            ],
            dtype=torch.long,
            device=device
        )

        # Forward pass
        logits = model(
            input_tokens
        )

        # Get logits for the final token
        next_token_logits = (
            logits[0, -1, :].clone()
        )

        # ----------------------------------------------------
        # REPETITION PENALTY
        # ----------------------------------------------------

        generated_list = (
            tokens[-max_seq_len:]
        )

        for token_id in set(
            generated_list
        ):

            token_count = (
                generated_list.count(
                    token_id
                )
            )

            penalty = (
                repetition_penalty
                + (
                    token_count * 0.1
                )
            )

            if next_token_logits[
                token_id
            ] > 0:

                next_token_logits[
                    token_id
                ] /= penalty

            else:

                next_token_logits[
                    token_id
                ] *= penalty


        # ----------------------------------------------------
        # TEMPERATURE
        # ----------------------------------------------------

        if temperature > 0:

            next_token_logits /= (
                temperature
            )


            # ------------------------------------------------
            # TOP-K
            # ------------------------------------------------

            if top_k > 0:

                k = min(
                    top_k,
                    next_token_logits.size(-1)
                )

                values, _ = torch.topk(
                    next_token_logits,
                    k
                )

                next_token_logits[
                    next_token_logits
                    < values[-1]
                ] = -float("Inf")


            # ------------------------------------------------
            # SOFTMAX
            # ------------------------------------------------

            probabilities = (
                torch.softmax(
                    next_token_logits,
                    dim=-1
                )
            )


            # ------------------------------------------------
            # TOP-P
            # ------------------------------------------------

            sorted_probs, sorted_indices = (
                torch.sort(
                    probabilities,
                    descending=True
                )
            )

            cumulative_probs = (
                torch.cumsum(
                    sorted_probs,
                    dim=-1
                )
            )

            sorted_indices_to_remove = (
                cumulative_probs > top_p
            )

            sorted_indices_to_remove[
                1:
            ] = (
                sorted_indices_to_remove[
                    :-1
                ].clone()
            )

            sorted_indices_to_remove[
                0
            ] = False

            indices_to_remove = (
                sorted_indices[
                    sorted_indices_to_remove
                ]
            )

            probabilities[
                indices_to_remove
            ] = 0.0

            probabilities /= (
                probabilities.sum()
            )


            # ------------------------------------------------
            # SAMPLE
            # ------------------------------------------------

            next_token = (
                torch.multinomial(
                    probabilities,
                    1
                ).item()
            )

        else:

            # Greedy decoding
            next_token = (
                next_token_logits
                .argmax(
                    dim=-1
                )
                .item()
            )


        # Add token
        tokens.append(
            next_token
        )


        # Stop at end-of-message
        if next_token == im_end_id:
            break


    # ========================================================
    # DECODE
    # ========================================================

    ai_response_tokens = (
        tokens[response_start:]
    )

    response = tokenizer.decode(
        ai_response_tokens
    )

    response = response.replace(
        "<|im_end|>",
        ""
    )

    return response.strip()


# ============================================================
# ATLAS RESPONSE
# ============================================================

SYSTEM_INSTRUCTION = (
    "You are AtlasOS, a helpful assistant. "
    "Your name is AtlasOS."
)


def generate_response(
    conversation
):

    formatted_conversation = []

    first_user_message = True

    for role, content in conversation:

        if (
            role == "user"
            and first_user_message
        ):

            content = (
                "[SYSTEM INSTRUCTION: "
                + SYSTEM_INSTRUCTION
                + "]\n\n"
                + "User Question: "
                + content
            )

            first_user_message = False

        formatted_conversation.append(
            (role, content)
        )


    response = generate(
        formatted_conversation,
        num_words=80,
        temperature=0.6,
        repetition_penalty=1.35,
        top_k=50,
        top_p=0.9
    )


    # Branding
    response = response.replace("ChatGLM-6B", "AtlasOS")
    response = response.replace("NAME_1", "AtlasOS")
    response = response.replace("Large Model Systems Organization (LMSYS)", "Revisioned Studios")
    response = response.replace("Anthropic", "Revisioned Studios")
    response = response.replace("Large Model Systems Organization", "Revisioned Studios")

    return response


# ============================================================
# TEST CHAT
# ============================================================

if __name__ == "__main__":

    print()
    print("=" * 50)
    print("AtlasOS is ready!")
    print("=" * 50)
    print("Type 'exit' to stop.")
    print()

    conversation = []

    while True:

        user_input = input(
            "You: "
        )

        if user_input.lower() == "exit":
            break

        conversation.append(
            ("user", user_input)
        )

        response = generate_response(
            conversation
        )

        conversation.append(
            ("assistant", response)
        )

        print(
            f"Atlas: {response}"
        )

        print()