# install backend packages: !pip install fastapi uvicorn

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from model import generate_response

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


class ChatRequest(BaseModel):
    message: str


@app.get("/")
def home():
    return {
        "status": "AtlasOS backend is running"
    }


@app.post("/chat")
def chat(request: ChatRequest):

    conversation = [
        ("user", request.message)
    ]

    response = generate_response(
        conversation
    )

    return {
        "response": response
    }